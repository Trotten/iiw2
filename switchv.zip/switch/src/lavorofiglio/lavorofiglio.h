
#ifndef LAVOROFIGLIO_H
#define LAVOROFIGLIO_H

//struttura dati per il passaggio di dati per il lavoro da eseguire dal processo principale al processo figlio

struct lavorofiglio
{		

	int suicidio;
};


#endif
