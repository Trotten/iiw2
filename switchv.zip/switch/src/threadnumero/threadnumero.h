#ifndef THREADNUMERO_H
#define THREADNUMERO_H


struct threadnumero
{
	int threadliberi;
	int threadoccupati;
	int *suicidio;
	//se serve inserire una lista di thread presenti nel processo

};


#endif

