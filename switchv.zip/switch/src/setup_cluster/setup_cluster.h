#ifndef SETUPCLUSTER_H
#define SETUPCLUSTER_H


struct setup_cluster
{

	int carico;
	int porta_carico;

};


#endif
