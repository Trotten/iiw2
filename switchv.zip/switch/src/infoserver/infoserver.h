#ifndef INFOSERVER_H
#define INFOSERVER_H


struct infoserver
{

	
	struct datipernuoviproc *pass;
	pthread_t threadcontrollo;

};


#endif
