#ifndef DATIPERNUOVIPROC_H
#define DATIPERNUOVIPROC_H


struct datipernuoviproc
{

	struct procinfo **procini;
	int listens;
	int fd_log;

};


#endif
