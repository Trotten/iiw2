#ifndef SERVERCLUSTER_H
#define SERVERCLUSTER_H


struct server_cluster{

	int carico;
	char* ip;

};


#endif

