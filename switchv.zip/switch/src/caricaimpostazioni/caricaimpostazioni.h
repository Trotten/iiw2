#ifndef CARICAIMPOSTAZIONI_H
#define CARICAIMPOSTAZIONI_H


struct impostazioni *inizzializzaimp();
struct impostazioni *caricaimpostazioni();


#endif
